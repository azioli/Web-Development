package com.android.csci571;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by LuGuanyu on 2017/4/20.
 */

public class AlbumItemsInfo {
    private String title;
    private List<String> photo_url_list = new ArrayList<>();

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getPhotoUrlList() {
        return photo_url_list;
    }

    public void setPhoto_url_list(List<String> photo_url_list) {
        this.photo_url_list = photo_url_list;
    }
}
