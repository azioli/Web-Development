package com.android.csci571;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DetailsActivity extends AppCompatActivity implements LoadDetailJSONTask.Listener {

    private final String PICTURE_URL_HEAD = "http://fbsearchm3y4s4s3n7.us-west-2.elasticbeanstalk.com/android_query.php?pic_id=";
    CallbackManager callbackManager;
    ShareDialog shareDialog;
    private int[] tabIcons = {
            R.drawable.ic_tab_albums,
            R.drawable.ic_tab_posts
    };
    private String[] tabTexts = {
            "Albums",
            "Posts"
    };
    private ViewPagerAdapter mViewPagerAdapter;
    private ViewPager mViewPager;
    private List<AlbumItemsInfo> mAlbumList = new ArrayList<>();
    private MyExpandableListAdapter mExpandableListAdapter;
    private ExpandableListView simpleExpandableListView;
    private Toolbar toolbar;
    private List<RecordGroup> RECORD_GROUPS;
    private List<RecordGroup> FAVORITE_GROUPS;
    private Map<String, String> mRecord;
    private String user_id;
    private int tabId;
    private boolean IS_FROM_RESULT_ACTIVITY = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        callbackManager = CallbackManager.Factory.create();
        shareDialog = new ShareDialog(this);
        shareDialog.registerCallback(callbackManager, new FacebookCallback<Sharer.Result>() {
            @Override
            public void onSuccess(Sharer.Result result) {
                Toast.makeText(DetailsActivity.this, "You shared this post.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancel() {
                Toast.makeText(DetailsActivity.this, "Sharing Canceled!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(FacebookException error) {
                Toast.makeText(DetailsActivity.this, "Error while sharing!", Toast.LENGTH_SHORT).show();
            }
        });
        setContentView(R.layout.activity_details);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        IS_FROM_RESULT_ACTIVITY = getIntent().getBooleanExtra("EXTRA_IS_FROM_RESULT_ACTIVITY", false);
        user_id = getIntent().getStringExtra("EXTRA_ID");
        tabId = Integer.parseInt(getIntent().getStringExtra("EXTRA_TAB_ID"));

        if (IS_FROM_RESULT_ACTIVITY) {
            RECORD_GROUPS = ResultActivity.RECORD_GROUPS;
        }
        FAVORITE_GROUPS = MainActivity.getFavoriteGroups();
        if (IS_FROM_RESULT_ACTIVITY) {
            mRecord = RECORD_GROUPS.get(tabId).recordMaps.get(user_id);
        } else {
            mRecord = FAVORITE_GROUPS.get(tabId).recordMaps.get(user_id);
        }
        mViewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(),
                DetailsActivity.this, 2, ViewPagerAdapter.DETAIL_MODE);
        mViewPager = (ViewPager) findViewById(R.id.view_pager);
        mViewPager.setOffscreenPageLimit(2);
        mViewPager.setAdapter(mViewPagerAdapter);


        TabLayout tabLayout = (TabLayout) findViewById(R.id.detail_tabs);
        tabLayout.setupWithViewPager(mViewPager);

        for (int i = 0; i < 2; i++) {
            TextView tab = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
            tab.setText(tabTexts[i]);
            tab.setCompoundDrawablesWithIntrinsicBounds(0, tabIcons[i], 0, 0);
            tabLayout.getTabAt(i).setCustomView(tab);
        }

        String url = "http://fbsearchm3y4s4s3n7.us-west-2.elasticbeanstalk.com/android_query.php?id=" + user_id;
        new LoadDetailJSONTask(this).execute(url);
    }

    @Override
    public void onDetailLoaded(JSONDetailResponse response) {
        if (response.albums != null && response.albums.data.size() != 0) {
            for (JSONAlbumItem.Album a : response.albums.data) {
                AlbumItemsInfo albumItemsInfo = new AlbumItemsInfo();
                albumItemsInfo.setTitle(a.name);
                List<String> list = new ArrayList<>();
                if (a.photos != null) {
                    for (JSONAlbumItem.Album.Photos.PhotoData photoData : a.photos.data) {
                        list.add(PICTURE_URL_HEAD + photoData.id);
                    }
                }
                albumItemsInfo.setPhoto_url_list(list);
                mAlbumList.add(albumItemsInfo);
            }

            simpleExpandableListView = (ExpandableListView) findViewById(R.id.expandable_list_view);
            mExpandableListAdapter = new MyExpandableListAdapter(DetailsActivity.this, mAlbumList);
            simpleExpandableListView.setAdapter(mExpandableListAdapter);

            simpleExpandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
                @Override
                public void onGroupExpand(int groupPosition) {
                    for (int i = 0; i < mExpandableListAdapter.getGroupCount(); i++) {
                        if (i != groupPosition)
                            simpleExpandableListView.collapseGroup(i);
                    }
                }
            });
            findViewById(R.id.no_albums_available).setVisibility(View.GONE);
        } else {
            findViewById(R.id.no_albums_available).setVisibility(View.VISIBLE);
        }

        if (response.posts != null && response.posts.data != null && response.posts.data.size() != 0) {
            List<Map<String, String>> postList = new ArrayList<>();
            for (JSONPostItem.Post post : response.posts.data) {
                Map<String, String> map = new HashMap<>();
                map.put("post_image", mRecord.get("photo_url"));
                map.put("post_name", mRecord.get("name"));
                map.put("post_time", post.created_time);
                map.put("post_message", post.message);
                postList.add(map);
            }
            ListView listView = (ListView) findViewById(R.id.posts_list_view);
            SimpleAdapter simpleAdapter = new SimpleAdapter(listView.getContext(), postList, R.layout.posts_list_item,
                    new String[]{"post_image", "post_name", "post_time", "post_message"},
                    new int[]{R.id.post_image, R.id.post_name, R.id.post_time, R.id.post_message});
            simpleAdapter.setViewBinder(new PostViewBinder());
            listView.setAdapter(simpleAdapter);
            findViewById(R.id.no_posts_available).setVisibility(View.GONE);
        } else {
            findViewById(R.id.no_posts_available).setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onError() {
        Toast.makeText(this, "Error while fetching data.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.details, menu);
        MenuItem add = menu.findItem(R.id.action_add_to_favorite);
        MenuItem remove = menu.findItem(R.id.action_remove_from_favorite);

        if (MainActivity.getFavoriteGroups().get(tabId).containsId(user_id)) {
            add.setVisible(false);
            remove.setVisible(true);
        } else {
            add.setVisible(true);
            remove.setVisible(false);
        }

        return true;
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        Menu menu = toolbar.getMenu();
        MenuItem add = menu.findItem(R.id.action_add_to_favorite);
        MenuItem remove = menu.findItem(R.id.action_remove_from_favorite);
        int id = item.getItemId();
        switch (id) {

            case R.id.action_add_to_favorite:
                FAVORITE_GROUPS.get(tabId).addRecord(mRecord);
                add.setVisible(false);
                remove.setVisible(true);
                if (RECORD_GROUPS != null)
                    RECORD_GROUPS.get(tabId).notifyBoundAdapter();
                FAVORITE_GROUPS.get(tabId).notifyBoundAdapter();
                MainActivity.putFavToFile(MainActivity.CONTEXT, FAVORITE_GROUPS, MainActivity.favoritesFileName);
                Toast.makeText(this, "Added to favorites.", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.action_remove_from_favorite:
                FAVORITE_GROUPS.get(tabId).removeRecord(mRecord.get("id"));
                remove.setVisible(false);
                add.setVisible(true);
                if (RECORD_GROUPS != null)
                    RECORD_GROUPS.get(tabId).notifyBoundAdapter();
                FAVORITE_GROUPS.get(tabId).notifyBoundAdapter();
                MainActivity.putFavToFile(MainActivity.CONTEXT, FAVORITE_GROUPS, MainActivity.favoritesFileName);
                Toast.makeText(this, "Removed from favorites.", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_share:

                ShareLinkContent content = new ShareLinkContent.Builder()
                        .setContentUrl(Uri.parse("http://fbsearchm3y4s4s3n7.us-west-2.elasticbeanstalk.com/"))
                        .setImageUrl(Uri.parse(mRecord.get("photo_url")))
                        .setContentTitle(mRecord.get("name"))
                        .setContentDescription("FB Search From USC CSCI571")
                        .build();
                shareDialog.show(content);
                Toast.makeText(this, "Sharing " + mRecord.get("name") + "!!", Toast.LENGTH_SHORT).show();

                return true;
            default:
                super.onBackPressed();
                return true;
        }
    }
}

class PostViewBinder implements SimpleAdapter.ViewBinder {

    @Override
    public boolean setViewValue(View view, Object data, String textRepresentation) {
        int id = view.getId();
        switch (id) {
            case R.id.post_image:
                ImageView imageView = (ImageView) view;
                ImageLoader.getInstance().displayImage((String) data, imageView, MainActivity.options);
                break;
            case R.id.post_name:
                ((TextView) view).setText((String) data);
                break;
            case R.id.post_time:
                String tmpStr = (String) data;
                ((TextView) view).setText(tmpStr.substring(0, tmpStr.length() - 5).replace('T', ' '));
                break;
            case R.id.post_message:
                ((TextView) view).setText((String) data);
                break;
            default:
                return false;
        }
        return true;
    }
}