package com.android.csci571;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleAdapter;

/**
 * Created by LuGuanyu on 2017/4/22.
 */

public class FavoritePageFragment extends Fragment {
    public static final String ARG_PAGE = "ARG_PAGE";
    public static final String ARG_TAB_ID = "ARG_TAB_ID";
    public int mPage;
    public int tabId;
    private View inflatedView;
    private SimpleAdapter mSimpleAdapter;

    public static FavoritePageFragment newInstance(int page) {
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE, page);
        args.putInt(ARG_TAB_ID, page - 1);
        FavoritePageFragment fragment = new FavoritePageFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPage = getArguments().getInt(ARG_PAGE);
        tabId = getArguments().getInt(ARG_TAB_ID);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (inflatedView == null) {
            inflatedView = inflater.inflate(R.layout.favorite_page_fragment, container, false);

            RecordGroup favGroup = MainActivity.getFavoriteGroups().get(tabId);
            /*
            Map<String,String> record=new HashMap<>();
            record.put("photo_url","");
            record.put("name","empty");
            record.put("id","empty");
            record.put("fav_id",tabId+"empty");
            favGroup.addRecord(record);
            */
            ListView listView = (ListView) inflatedView.findViewById(R.id.list_view);
            mSimpleAdapter = new SimpleAdapter(listView.getContext(), favGroup.recordItems, R.layout.record_list_item,
                    new String[]{"photo_url", "name", "fav_id", "fav_id"},
                    new int[]{R.id.profile_image_frame, R.id.user_name, R.id.fav_icon, R.id.go_details});
            mSimpleAdapter.setViewBinder(new MyViewBinder(getContext(), favGroup));
            listView.setAdapter(mSimpleAdapter);
            favGroup.addAdapter(mSimpleAdapter);
            //favGroup.removeRecord("empty");
            //favGroup.notifyBoundAdapter();
        }
        return inflatedView;
    }

    @Override
    public View getView() {
        return inflatedView;
    }
}
