package com.android.csci571;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;

/**
 * Created by LuGuanyu on 2017/4/22.
 */

public class FavoritesFragment extends Fragment {

    public static final String ARG_PAGE = "ARG_PAGE";
    //private ViewPagerAdapter mViewPagerAdapter;
    public static ViewPagerAdapter mViewPagerAdapter;
    private final int PAGE_COUNT = 5;
    public int mPage;
    private int[] tabIcons = {
            R.drawable.ic_tab_users,
            R.drawable.ic_tab_pages,
            R.drawable.ic_tab_events,
            R.drawable.ic_tab_places,
            R.drawable.ic_tab_groups
    };
    private String[] tabTexts = {
            "Users",
            "Pages",
            "Events",
            "Places",
            "Groups"
    };
    private ViewPager mViewPager;
    private Context context;
    private View inflatedView;

    private DisplayImageOptions options = new DisplayImageOptions.Builder()
            .cacheInMemory(true)
            .cacheOnDisk(true)
            .imageScaleType(ImageScaleType.EXACTLY)
            .bitmapConfig(Bitmap.Config.RGB_565)
            .considerExifParams(true)
            .build();

    public static FavoritesFragment newInstance(int page) {
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE, page);
        FavoritesFragment fragment = new FavoritesFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPage = getArguments().getInt(ARG_PAGE);
        context = getContext();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (inflatedView == null) {
            inflatedView = inflater.inflate(R.layout.favorites_fragment, container, false);

            mViewPagerAdapter = new ViewPagerAdapter(getFragmentManager(),
                    inflatedView.getContext(), PAGE_COUNT, ViewPagerAdapter.FAVORITE_MODE);
            mViewPager = (ViewPager) inflatedView.findViewById(R.id.favorites_view_pager);
            mViewPager.setOffscreenPageLimit(PAGE_COUNT);
            mViewPager.setAdapter(mViewPagerAdapter);

            TabLayout tabLayout = (TabLayout) inflatedView.findViewById(R.id.favorite_tabs);
            tabLayout.setupWithViewPager(mViewPager);
            for (int i = 0; i < PAGE_COUNT; i++) {
                TextView tab = (TextView) LayoutInflater.from(inflatedView.getContext()).inflate(R.layout.custom_tab, null);
                tab.setText(tabTexts[i]);
                tab.setCompoundDrawablesWithIntrinsicBounds(0, tabIcons[i], 0, 0);
                tabLayout.getTabAt(i).setCustomView(tab);
            }

        }
        return inflatedView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public View getView() {
        return inflatedView;
    }

    public ViewPagerAdapter getmViewPagerAdapter() {
        return mViewPagerAdapter;
    }
}
