package com.android.csci571;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

/**
 * Created by LuGuanyu on 2017/4/21.
 */

public class HomeFragment extends Fragment {
    public static final String ARG_PAGE = "ARG_PAGE";
    public int mPage;

    private View inflatedView;

    public static HomeFragment newInstance(int page) {
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE, page);
        HomeFragment fragment = new HomeFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPage = getArguments().getInt(ARG_PAGE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (inflatedView == null) {
            inflatedView = inflater.inflate(R.layout.home_fragment, container, false);
            Button btn_search = (Button) inflatedView.findViewById(R.id.btn_search);
            btn_search.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AutoCompleteTextView textView = (AutoCompleteTextView) inflatedView.findViewById(R.id.autoCompleteTextView);
                    String keyword = textView.getText().toString();
                    if (keyword.matches("")) {
                        Toast.makeText(inflatedView.getContext(), "Please enter a keyword!", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Intent intent = new Intent(inflatedView.getContext(), ResultActivity.class);
                    intent.putExtra("EXTRA_KEYWORD", keyword);
                    startActivity(intent);
                    return;
                }
            });

            Button btn_clear = (Button) inflatedView.findViewById(R.id.btn_clear);
            btn_clear.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AutoCompleteTextView textView = (AutoCompleteTextView) inflatedView.findViewById(R.id.autoCompleteTextView);
                    textView.setText("");
                    return;
                }
            });
        }
        return inflatedView;
    }
}
