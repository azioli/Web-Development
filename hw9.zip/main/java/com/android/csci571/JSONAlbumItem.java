package com.android.csci571;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by LuGuanyu on 2017/4/21.
 */

public class JSONAlbumItem {
    public List<Album> data = new ArrayList<>();

    class Album {
        public String name;
        public Photos photos = new Photos();

        class Photos {
            public List<PhotoData> data = new ArrayList<>();

            class PhotoData {
                public String name;
                public String id;
            }
        }
    }
}