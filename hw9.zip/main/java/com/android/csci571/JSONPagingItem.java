package com.android.csci571;

/**
 * Created by LuGuanyu on 2017/4/15.
 */

public class JSONPagingItem {
    private String previous = null;
    private String next = null;

    public String getPrevious() {
        return this.previous;
    }

    public String getNext() {
        return this.next;
    }
}
