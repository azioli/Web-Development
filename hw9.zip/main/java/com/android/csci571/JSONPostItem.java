package com.android.csci571;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by LuGuanyu on 2017/4/21.
 */

public class JSONPostItem {
    public List<Post> data = new ArrayList<>();

    class Post {
        public String created_time;
        public String message;

    }
}
