package com.android.csci571;

/**
 * Created by LuGuanyu on 2017/4/15.
 */

public class JSONRecordItem {
    private String id = null;
    private String name = null;
    private Picture picture = new Picture();

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getPictureUrl() {
        return picture.getUrl();
    }

    class Picture {
        PictureData data = new PictureData();

        String getUrl() {
            return data.getUrl();
        }

        class PictureData {
            String url = null;

            String getUrl() {
                return this.url;
            }
        }
    }
}
