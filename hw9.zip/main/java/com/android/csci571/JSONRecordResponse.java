package com.android.csci571;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by LuGuanyu on 2017/4/15.
 */

public class JSONRecordResponse {
    private List<JSONRecordItem> data = new ArrayList<>();
    private JSONPagingItem paging = new JSONPagingItem();

    public List<JSONRecordItem> getData() {
        return this.data;
    }

    public JSONPagingItem getPaging() {
        return this.paging;
    }
}
