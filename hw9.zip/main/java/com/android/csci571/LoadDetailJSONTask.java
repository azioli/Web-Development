package com.android.csci571;

import android.os.AsyncTask;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoadDetailJSONTask extends AsyncTask<String, Void, JSONDetailResponse> {

    private Listener mListener;

    public LoadDetailJSONTask(Listener listener) {
        mListener = listener;
    }

    private String loadJSON(String jsonURL) throws IOException {

        URL url = new URL(jsonURL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setReadTimeout(10000);
        conn.setConnectTimeout(15000);
        conn.setRequestMethod("GET");
        conn.setDoInput(true);
        conn.connect();

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String line = "";
        StringBuilder sb = new StringBuilder();
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        br.close();
        return sb.toString();
    }

    @Override
    protected JSONDetailResponse doInBackground(String... strings) {
        try {
            String jsonString = loadJSON(strings[0]);
            Gson gson = new Gson();
            JSONDetailResponse jsonDetailResponse = gson.fromJson(jsonString, JSONDetailResponse.class);
            return jsonDetailResponse;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onPostExecute(JSONDetailResponse response) {

        if (response != null) {

            mListener.onDetailLoaded(response);

        } else {

            mListener.onError();
        }
    }


    public interface Listener {
        void onDetailLoaded(JSONDetailResponse response);

        void onError();
    }

}

class JSONDetailResponse {
    public JSONAlbumItem albums = new JSONAlbumItem();
    public JSONPostItem posts = new JSONPostItem();
}

