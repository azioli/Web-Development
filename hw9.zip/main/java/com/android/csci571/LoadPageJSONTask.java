package com.android.csci571;

import android.os.AsyncTask;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class LoadPageJSONTask extends AsyncTask<String, Void, JSONRecordResponse> {
    public int tabId;
    private Listener mListener;

    public LoadPageJSONTask(Listener listener, int tabId) {
        mListener = listener;
        this.tabId = tabId;
    }

    private String loadJSON(String jsonURL) throws IOException {
        URL url = new URL(jsonURL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        //conn.setReadTimeout(10000);
        //conn.setConnectTimeout(15000);
        conn.setRequestMethod("GET");
        //conn.setDoInput(true);
        conn.connect();

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String line = "";
        StringBuilder sb = new StringBuilder();
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        br.close();
        return sb.toString();
    }

    @Override
    protected JSONRecordResponse doInBackground(String... strings) {
        try {
            Map<String, JSONRecordResponse> map = new HashMap<>();
            String jsonStrings = loadJSON(strings[0]);
            Gson gson = new Gson();
            JSONRecordResponse jsonRecordResponse = gson.fromJson(jsonStrings, JSONRecordResponse.class);
            return jsonRecordResponse;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onPostExecute(JSONRecordResponse response) {

        if (response != null) {

            mListener.onPageLoaded(response, tabId);

        } else {

            mListener.onError();
        }
    }


    public interface Listener {
        void onPageLoaded(JSONRecordResponse response, int tabId);

        void onError();
    }

}
