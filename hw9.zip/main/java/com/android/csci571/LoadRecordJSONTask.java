package com.android.csci571;

import android.content.Context;
import android.location.Location;
import android.os.AsyncTask;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class LoadRecordJSONTask extends AsyncTask<String, Void, Map<String, JSONRecordResponse>> {
    private static String[] TYPES = {"Users", "Pages", "Events", "Places", "Groups"};
    private Location mLastLocation;
    private Listener mListener;

    public LoadRecordJSONTask(Context context, Listener listener, String[] types) {
        mListener = listener;
        this.TYPES = types;
        this.mLastLocation = MainActivity.getLastLocation();
    }

    private String[] loadJSON(String jsonURL) throws IOException {
        String[] ret = new String[TYPES.length];
        for (int i = 0; i < TYPES.length; i++) {
            String urlString = jsonURL + "&type=" + TYPES[i];
            if (TYPES[i].equals("Places")) {
                mLastLocation = MainActivity.getLastLocation();
                if (mLastLocation != null) {
                    String latitude_user = String.valueOf(mLastLocation.getLatitude());
                    String longitude_user = String.valueOf(mLastLocation.getLongitude());
                    urlString += "&lon=" + longitude_user + "&lat=" + latitude_user;
                }
            }
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.connect();

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line = "";
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
            ret[i] = sb.toString();
        }
        return ret;
    }

    @Override
    protected Map<String, JSONRecordResponse> doInBackground(String... strings) {
        try {
            Map<String, JSONRecordResponse> map = new HashMap<>();
            String[] jsonStrings = loadJSON(strings[0]);
            Gson gson = new Gson();
            for (int i = 0; i < TYPES.length; i++) {
                JSONRecordResponse jsonRecordResponse = gson.fromJson(jsonStrings[i], JSONRecordResponse.class);
                map.put(TYPES[i], jsonRecordResponse);
            }
            return map;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onPostExecute(Map<String, JSONRecordResponse> response) {

        if (response != null) {

            mListener.onRecordLoaded(response);

        } else {

            mListener.onError();
        }
    }


    public interface Listener {
        void onRecordLoaded(Map<String, JSONRecordResponse> response);

        void onError();
    }

}
