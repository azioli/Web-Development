package com.android.csci571;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
    public static final int PAGE_COUNT = 5;
    public static final String favoritesFileName = "favorites.json";
    public static DisplayImageOptions options = new DisplayImageOptions.Builder()
            .cacheInMemory(true)
            .cacheOnDisk(true)
            .imageScaleType(ImageScaleType.EXACTLY)
            .bitmapConfig(Bitmap.Config.RGB_565)
            .considerExifParams(true)
            .build();
    public static List<RecordGroup> FAVORITE_GROUPS = new ArrayList<RecordGroup>();
    public static ViewPagerAdapter mViewPagerAdapter;
    ;
    public static Gson gson = new Gson();
    public static Context CONTEXT;
    private static Location mLastLocation;
    private int[] tabIcons = {
            R.drawable.ic_tab_users,
            R.drawable.ic_tab_pages,
            R.drawable.ic_tab_events,
            R.drawable.ic_tab_places,
            R.drawable.ic_tab_groups
    };
    private String[] tabTexts = {
            "Users",
            "Pages",
            "Events",
            "Places",
            "Groups"
    };
    private HomeFragment homeFragment;
    private FavoritesFragment favoritesFragment;
    private ViewPager mViewPager;
    private View favoritesView;
    private GoogleApiClient mGoogleApiClient;

    public static List<RecordGroup> getFavoriteGroups() {
        return FAVORITE_GROUPS;
    }

    public static void putFavToFile(Context context, List<RecordGroup> recordGroups, String fileName) {
        List<SerializableRecordGroup> serializableRecordGroups = new ArrayList<>();
        for (RecordGroup recordGroup : recordGroups) {
            serializableRecordGroups.add(new SerializableRecordGroup(recordGroup));
        }
        try {
            FileOutputStream fileOutputStream = context.openFileOutput(fileName, Context.MODE_PRIVATE);
            String jsonString = gson.toJson(new RecordGroupsJSONWrapper(serializableRecordGroups));
            fileOutputStream.write(jsonString.getBytes());
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Location getLastLocation() {
        return mLastLocation;
    }

    private void getFavFromFile(File file) {
        try {
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line = null;
            if ((line = bufferedReader.readLine()) != null) {
                FAVORITE_GROUPS.clear();
                RecordGroupsJSONWrapper recordGroupsJSONWrapper = gson.fromJson(line, RecordGroupsJSONWrapper.class);
                for (SerializableRecordGroup serializableRecordGroup : recordGroupsJSONWrapper.recordGroups) {
                    FAVORITE_GROUPS.add(new RecordGroup(serializableRecordGroup));
                }
                if (FAVORITE_GROUPS.size() != PAGE_COUNT)
                    FAVORITE_GROUPS.clear();
            }
            bufferedReader.close();
            fileReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        buildGoogleApiClient();
        onStart();

        CONTEXT = this;

        File file = new File(getFilesDir(), favoritesFileName);


        if (!file.exists()) {
            for (int i = 0; i < PAGE_COUNT; i++) {
                RecordGroup favGroup = new RecordGroup();
                Map<String, String> record = new HashMap<>();
                record.put("photo_url", "empty");
                record.put("name", "empty");
                record.put("id", "empty");
                record.put("fav_id", i + "empty");
                favGroup.addRecord(record);
                FAVORITE_GROUPS.add(favGroup);
            }
        } else {
            getFavFromFile(file);
        }

        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(this).build();
        ImageLoader.getInstance().init(config);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        homeFragment = HomeFragment.newInstance(1);
        favoritesFragment = FavoritesFragment.newInstance(2);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.content_frame, homeFragment)
                .commit();
        navigationView.getMenu().findItem(R.id.nav_home).setChecked(true);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.clear_favorites) {
            File file = new File(getFilesDir(), favoritesFileName);
            if (file.exists()) {
                try {
                    file.getCanonicalFile().delete();
                    FAVORITE_GROUPS.clear();
                    for (int i = 0; i < PAGE_COUNT; i++) {
                        RecordGroup favGroup = new RecordGroup();
                        Map<String, String> record = new HashMap<>();
                        record.put("photo_url", "empty");
                        record.put("name", "empty");
                        record.put("id", "empty");
                        record.put("fav_id", i + "empty");
                        favGroup.addRecord(record);
                        FAVORITE_GROUPS.add(favGroup);
                    }
                    Toast.makeText(this, "Favorites cleared!", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.content_frame, homeFragment)
                    .commit();
        } else if (id == R.id.nav_favorites) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.content_frame, favoritesFragment)
                    .commit();
        } else if (id == R.id.nav_about_me) {
            Intent intent = new Intent(MainActivity.this, AboutMeActivity.class);
            startActivity(intent);
            return true;
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    protected synchronized void buildGoogleApiClient() {

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();

    }

    protected void onStart() {
        mGoogleApiClient.connect();
        super.onStart();
    }

    protected void onStop() {
        mGoogleApiClient.disconnect();
        super.onStop();
    }

    @Override
    public void onConnected(Bundle connectionHint) {


        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    200);
        } else {
            mLastLocation = LocationServices.FusedLocationApi.getLastLocation(
                    mGoogleApiClient);
        }
    }

    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        if (requestCode == 200) {
            if (grantResults.length == 1
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // We can now safely use the API we requested access to
                mLastLocation =
                        LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
            } else {
                Toast.makeText(this, "Cannot get location!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onConnectionSuspended(int i) {
        Toast.makeText(this, "Connection suspended...", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Toast.makeText(this, "Failed to connect...", Toast.LENGTH_SHORT).show();
    }
}

class RecordGroupsJSONWrapper {
    List<SerializableRecordGroup> recordGroups;

    public RecordGroupsJSONWrapper(List<SerializableRecordGroup> recordGroups) {
        this.recordGroups = recordGroups;
    }
}