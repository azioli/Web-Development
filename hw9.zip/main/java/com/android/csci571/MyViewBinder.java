package com.android.csci571;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.ImageSize;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.util.List;

/**
 * Created by LuGuanyu on 2017/4/22.
 */

public class MyViewBinder implements SimpleAdapter.ViewBinder {

    private Context context;

    private DisplayImageOptions options = new DisplayImageOptions.Builder()
            .cacheInMemory(true)
            .cacheOnDisk(true)
            .imageScaleType(ImageScaleType.EXACTLY)
            .bitmapConfig(Bitmap.Config.RGB_565)
            .considerExifParams(true)
            .build();
    private List<RecordGroup> FAVORITE_GROUPS;
    private RecordGroup mRecordGroup;

    public MyViewBinder(Context context, RecordGroup recordGroup) {
        this.context = context;
        FAVORITE_GROUPS = MainActivity.FAVORITE_GROUPS;
        mRecordGroup = recordGroup;
    }

    @Override
    public boolean setViewValue(View view, Object data, String textRepresentation) {
        int id = view.getId();
        switch (id) {
            case R.id.profile_image_frame:
                String url = (String) data;
                if (url.equals("empty"))
                    break;
                ImageSize imageSize = new ImageSize(80, 80);
                final ImageView imageView = (ImageView) view.findViewById(R.id.profile_image);
                final ProgressBar spinner = (ProgressBar) view.findViewById(R.id.loading);
                ImageLoader.getInstance().displayImage(url, imageView, options, new SimpleImageLoadingListener() {
                    @Override
                    public void onLoadingStarted(String imageUri, View view) {
                        //ProgressBar spinner= (ProgressBar) ((View)view.getParent()).findViewById(R.id.loading);
                        imageView.setVisibility(View.INVISIBLE);
                        spinner.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                        String message = null;
                        //ProgressBar spinner= (ProgressBar) ((View)view.getParent()).findViewById(R.id.loading);
                        switch (failReason.getType()) {
                            case IO_ERROR:
                                message = "Input/Output error";
                                break;
                            case DECODING_ERROR:
                                message = "Image can't be decoded";
                                break;
                            case NETWORK_DENIED:
                                message = "Downloads are denied";
                                break;
                            case OUT_OF_MEMORY:
                                message = "Out Of Memory error";
                                break;
                            case UNKNOWN:
                                message = "Unknown error";
                                break;
                        }
                        Toast.makeText(view.getContext(), message, Toast.LENGTH_SHORT).show();
                        imageView.setVisibility(View.VISIBLE);
                        spinner.setVisibility(View.GONE);
                    }

                    @Override
                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                        //ProgressBar spinner= (ProgressBar) ((View)view.getParent()).findViewById(R.id.loading);
                        imageView.setVisibility(View.VISIBLE);
                        spinner.setVisibility(View.GONE);
                    }
                });
                break;
            case R.id.user_name:
                ((TextView) view).setText((String) data);
                break;
            case R.id.fav_icon:
                String fav_id = (String) data;
                if (fav_id.substring(1).equals("empty")) {
                    LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            0
                    );
                    ((View) view.getParent()).setLayoutParams(param);
                    ((View) view.getParent()).setVisibility(View.GONE);
                    break;
                }
                if (fav_id != null && fav_id.length() >= 2) {
                    int tabId = Integer.parseInt(fav_id.substring(0, 1));
                    String rid = fav_id.substring(1);
                    ImageView favIcon = (ImageView) view;
                    if (FAVORITE_GROUPS.get(tabId).containsId(rid)) {
                        favIcon.setImageResource(R.mipmap.ic_favorites_on);
                    } else {
                        favIcon.setImageResource(R.drawable.ic_favorites_off);
                    }
                }
                break;

            case R.id.go_details:
                final String tabId = (String) ((String) data).substring(0, 1);
                final String user_id = (String) ((String) data).substring(1);
                if (user_id.equals("empty"))
                    break;
                view.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        Intent intent = new Intent(context, DetailsActivity.class);
                        Bundle bundle = new Bundle();
                        //bundle.putSerializable("VALUE",(HashMap)mRecordGroup.recordMaps.get(user_id));
                        intent.putExtra("EXTRA_TAB_ID", tabId);
                        intent.putExtra("EXTRA_ID", user_id);
                        intent.putExtra("EXTRA_RECORD", bundle);
                        intent.putExtra("EXTRA_IS_FROM_RESULT_ACTIVITY", context.getClass().getName().equals("com.android.csci571.ResultActivity") ? true : false);
                        context.startActivity(intent);
                    }
                });
        }
        return true;
    }
}