package com.android.csci571;

import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by LuGuanyu on 2017/4/17.
 */

public class RecordGroup {
    public List<Map<String, String>> recordItems = new ArrayList<>();
    public String prev = null;
    public String next = null;
    public Map<String, Map<String, String>> recordMaps = new HashMap<>();
    public List<SimpleAdapter> adapterList = new ArrayList<>();

    public RecordGroup() {
        //Default Constructor
    }

    public RecordGroup(List<Map<String, String>> recordItems, String prev, String next) {
        this.recordItems.addAll(recordItems);
        for (Map<String, String> map : recordItems) {
            recordMaps.put(map.get("id"), map);
        }
        this.prev = prev;
        this.next = next;
    }

    public RecordGroup(SerializableRecordGroup serializableRecordGroup) {
        this.recordItems.addAll(serializableRecordGroup.recordItems);
        this.prev = serializableRecordGroup.prev;
        this.next = serializableRecordGroup.next;
        for (Map<String, String> map : this.recordItems) {
            recordMaps.put(map.get("id"), map);
        }
    }

    public void update(List<Map<String, String>> recordItems, String prev, String next) {
        this.recordItems.clear();
        this.recordItems.addAll(recordItems);
        this.recordMaps.clear();
        for (Map<String, String> map : this.recordItems) {
            recordMaps.put(map.get("id"), map);
        }
        this.prev = prev;
        this.next = next;
    }

    public boolean containsId(String rid) {
        return recordMaps.containsKey(rid);
    }

    public void addRecord(Map<String, String> record) {
        recordItems.add(record);
        recordMaps.put(record.get("id"), record);
    }

    public void removeRecord(String rid) {
        Iterator<Map<String, String>> it = recordItems.iterator();
        while (it.hasNext()) {
            Map<String, String> map = it.next();
            if (map.get("id").equals(rid)) {
                it.remove();
                break;
            }
        }
        recordMaps.remove(rid);
    }

    public void addAdapter(SimpleAdapter adapter) {
        adapterList.add(adapter);
    }

    public void notifyBoundAdapter() {
        for (SimpleAdapter adapter : adapterList) {
            adapter.notifyDataSetChanged();
        }
    }
}
