package com.android.csci571;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

// In this case, the fragment displays simple text based on the page
public class RecordPageFragment extends Fragment {
    public static final String ARG_PAGE = "ARG_PAGE";
    public int mPage;
    private View inflatedView;
    private Button btn_prev;
    private Button btn_next;

    public static RecordPageFragment newInstance(int page) {
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE, page);
        RecordPageFragment fragment = new RecordPageFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPage = getArguments().getInt(ARG_PAGE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (inflatedView == null) {
            inflatedView = inflater.inflate(R.layout.record_fragment, container, false);
            btn_prev = (Button) inflatedView.findViewById(R.id.btn_prev);
            btn_next = (Button) inflatedView.findViewById(R.id.btn_next);
        }
        return inflatedView;
    }

    public void setPagingButton(RecordGroup recordGroup) {
        btn_next.setEnabled(recordGroup.next != null);
        btn_prev.setEnabled(recordGroup.prev != null);
        /*if(recordGroup.recordItems.isEmpty()){
            btn_next.setVisibility(View.INVISIBLE);
            btn_prev.setVisibility(View.INVISIBLE);
        }
        else{
            btn_next.setVisibility(View.VISIBLE);
            btn_prev.setVisibility(View.VISIBLE);
        }*/
    }

    @Override
    public View getView() {
        return inflatedView;
    }
}
