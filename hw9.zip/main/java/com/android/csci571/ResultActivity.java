package com.android.csci571;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ResultActivity extends AppCompatActivity implements LoadRecordJSONTask.Listener, LoadPageJSONTask.Listener {

    public static final int PAGE_COUNT = 5;
    public static ViewPagerAdapter mViewPagerAdapter;
    public static List<RecordGroup> RECORD_GROUPS = new ArrayList<>();

    static {
        for (int i = 0; i < PAGE_COUNT; i++) {
            RECORD_GROUPS.add(new RecordGroup());
        }
    }

    private int[] tabIcons = {
            R.drawable.ic_tab_users,
            R.drawable.ic_tab_pages,
            R.drawable.ic_tab_events,
            R.drawable.ic_tab_places,
            R.drawable.ic_tab_groups
    };
    private String[] tabTexts = {
            "Users",
            "Pages",
            "Events",
            "Places",
            "Groups"
    };
    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_result);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Get the ViewPager and set it's PagerAdapter so that it can display items

        mViewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(),
                ResultActivity.this, PAGE_COUNT, ViewPagerAdapter.RECORD_MODE);
        mViewPager = (ViewPager) findViewById(R.id.view_pager);
        mViewPager.setOffscreenPageLimit(PAGE_COUNT);
        mViewPager.setAdapter(mViewPagerAdapter);

        // Give the TabLayout the ViewPager

        TabLayout tabLayout = (TabLayout) findViewById(R.id.result_tabs);
        tabLayout.setupWithViewPager(mViewPager);

        for (int i = 0; i < PAGE_COUNT; i++) {
            TextView tab = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
            tab.setText(tabTexts[i]);
            tab.setCompoundDrawablesWithIntrinsicBounds(0, tabIcons[i], 0, 0);
            tabLayout.getTabAt(i).setCustomView(tab);
        }

        AutoCompleteTextView textView = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
        String keyword = getIntent().getStringExtra("EXTRA_KEYWORD");
        String url = "http://fbsearchm3y4s4s3n7.us-west-2.elasticbeanstalk.com/android_query.php?keyword=" + keyword;
        onStart();

        new LoadRecordJSONTask(this, this, tabTexts).execute(url);
    }

    @Override
    public void onRecordLoaded(Map<String, JSONRecordResponse> response) {
        for (int i = 0; i < PAGE_COUNT; i++) {
            List<Map<String, String>> list = new ArrayList<>();
            for (JSONRecordItem r : response.get(tabTexts[i]).getData()) {
                Map<String, String> map = new HashMap<>();
                map.put("photo_url", r.getPictureUrl());
                map.put("name", r.getName());
                map.put("id", r.getId());
                map.put("fav_id", i + r.getId());
                list.add(map);
            }
            JSONPagingItem paging = response.get(tabTexts[i]).getPaging();
            RECORD_GROUPS.set(i, new RecordGroup(list, paging.getPrevious(), paging.getNext()));
        }
        loadListView();
    }

    @Override
    public void onPageLoaded(JSONRecordResponse response, int tabId) {
        List<Map<String, String>> list = new ArrayList<>();
        for (JSONRecordItem r : response.getData()) {
            Map<String, String> map = new HashMap<>();
            map.put("photo_url", r.getPictureUrl());
            map.put("name", r.getName());
            map.put("id", r.getId());
            map.put("fav_id", tabId + r.getId());
            list.add(map);
        }
        JSONPagingItem paging = response.getPaging();
        RECORD_GROUPS.get(tabId).update(list, paging.getPrevious(), paging.getNext());

        ((RecordPageFragment) mViewPagerAdapter.getItem(tabId)).setPagingButton(RECORD_GROUPS.get(tabId));
        ListView listView = (ListView) mViewPagerAdapter.getItem(tabId).getView().findViewById(R.id.list_view);
        SimpleAdapter adapter = (SimpleAdapter) listView.getAdapter();
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onError() {
        Toast.makeText(this, "Error while fetching data!", Toast.LENGTH_SHORT).show();
    }

    private void loadListView() {

        for (int i = 0; i < PAGE_COUNT; i++) {
            loadRecordData(i, (RecordPageFragment) mViewPagerAdapter.getItem(i), RECORD_GROUPS);
        }

    }

    public void loadRecordData(final int tabId, RecordPageFragment fragment, List<RecordGroup> recordGroups) {
        ListView listView = (ListView) fragment.getView().findViewById(R.id.list_view);
        RecordGroup recordGroup = recordGroups.get(tabId);
        SimpleAdapter adapter = new SimpleAdapter(listView.getContext(), recordGroup.recordItems, R.layout.record_list_item,
                new String[]{"photo_url", "name", "fav_id", "fav_id"},
                new int[]{R.id.profile_image_frame, R.id.user_name, R.id.fav_icon, R.id.go_details});
        adapter.setViewBinder(new MyViewBinder(ResultActivity.this, recordGroup));
        listView.setAdapter(adapter);
        Button btn_next = (Button) fragment.getView().findViewById(R.id.btn_next);
        recordGroup.addAdapter(adapter);

        btn_next.setVisibility(View.VISIBLE);
        btn_next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click
                new LoadPageJSONTask((ResultActivity) v.getContext(), tabId).execute(RECORD_GROUPS.get(tabId).next);
            }
        });

        Button btn_prev = (Button) fragment.getView().findViewById(R.id.btn_prev);
        btn_prev.setVisibility(View.VISIBLE);

        btn_prev.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new LoadPageJSONTask((ResultActivity) v.getContext(), tabId).execute(RECORD_GROUPS.get(tabId).prev);
            }
        });
        ((RecordPageFragment) mViewPagerAdapter.getItem(tabId)).setPagingButton(RECORD_GROUPS.get(tabId));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        super.onBackPressed();
        return true;
    }

}

