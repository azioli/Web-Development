package com.android.csci571;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Created by LuGuanyu on 2017/4/24.
 */

public class SerializableRecordGroup implements Serializable {
    public List<Map<String, String>> recordItems;
    public String prev = null;
    public String next = null;
    public Map<String, Map<String, String>> recordMaps;

    public SerializableRecordGroup(RecordGroup recordGroup) {
        this.recordItems = recordGroup.recordItems;
        this.prev = recordGroup.prev;
        this.next = recordGroup.next;
        this.recordMaps = recordGroup.recordMaps;
    }
}
