package com.android.csci571;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by LuGuanyu on 2017/4/16.
 */

public class ViewPagerAdapter extends FragmentPagerAdapter {
    public static final int RECORD_MODE = 0;
    public static final int DETAIL_MODE = 1;
    public static final int FAVORITE_MODE = 2;
    //private String tabTitles[] = new String[] { "Tab1", "Tab2", "Tab3","Tab4","Tab5"};
    private Context context;
    private List<Fragment> mFragmentList = new ArrayList<>();

    public ViewPagerAdapter(FragmentManager fm, Context context, int PAGE_COUNT, int MODE) {
        super(fm);
        this.context = context;
        switch (MODE) {
            case RECORD_MODE:
                for (int i = 0; i < PAGE_COUNT; i++) {
                    mFragmentList.add(RecordPageFragment.newInstance(i + 1));
                }
                break;
            case DETAIL_MODE:
                mFragmentList.add(AlbumFragment.newInstance(1));
                mFragmentList.add(PostFragment.newInstance(2));
                break;
            case FAVORITE_MODE:
                for (int i = 0; i < PAGE_COUNT; i++) {
                    mFragmentList.add(FavoritePageFragment.newInstance(i + 1));
                }
                break;
        }
    }

    @Override
    public int getCount() {
        return mFragmentList.size();
    }

    @Override
    public Fragment getItem(int position) {
        return mFragmentList.get(position);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        // Generate title based on item position
        //return tabTitles[position];
        return null;
    }

    /*
    @Override
    public void notifyDataSetChanged(){
        super.notifyDataSetChanged();
        TabLayout tabLayout = (TabLayout) inflatedView.findViewById(R.id.favorite_tabs);
        tabLayout.setupWithViewPager(mViewPager);
        for (int i = 0; i < PAGE_COUNT; i++) {
            TextView tab = (TextView) LayoutInflater.from(inflatedView.getContext()).inflate(R.layout.custom_tab, null);
            tab.setText(tabTexts[i]);
            tab.setCompoundDrawablesWithIntrinsicBounds(0, tabIcons[i], 0, 0);
            tabLayout.getTabAt(i).setCustomView(tab);
        }
    }
    */
}